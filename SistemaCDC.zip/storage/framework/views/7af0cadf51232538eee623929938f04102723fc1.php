
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">

            <?php if(Session::has('editEntrada')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>¡Cambios guardados correctamente!</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            <?php endif; ?>


            <h4 class="card-title">Editar: <?php echo e($ingreso->id); ?> </h4>
            
            <form action="<?php echo e(url('/entradas/'.$ingreso->id)); ?>" class="needs-validation" id="formGuias" method="POST" novalidate>
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PATCH')); ?>

              <div class="form-group row">
                <label for="exampleInputUsername2" class="col-sm-3 col-form-label">Tracking/Perteneciente</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="tgp" id="tgp" value="<?php echo e($ingreso->tgp); ?>" autofocus>
                    <input type="hidden" name="id" id="id" value="<?php echo e($ingreso->id); ?>">
                    <input type="hidden" id="user_id" name="user_id" value=" <?php echo e(Auth::user()->id); ?>">
                </div>
              </div>
              <div class="form-group row">
                <label for="exampleInputEmail2" class="col-sm-3 col-form-label">Peso *</label>
                <div class="col-sm-9">
                    <input type="number" step="any" name="peso" id="peso" class="form-control" value="<?php echo e($ingreso->peso); ?>" required/>
                </div>
              </div>
              <div class="form-group row">
                <label for="exampleInputMobile" class="col-sm-3 col-form-label">Alto *</label>
                <div class="col-sm-9">
                    <input type="number" step="any" name="alto" id="alto" class="form-control" value="<?php echo e($ingreso->alto); ?>" required/>
                </div>
              </div>
              <div class="form-group row">
                <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Largo *</label>
                <div class="col-sm-9">
                    <input type="number" step="any" name="largo" id="largo" class="form-control" value="<?php echo e($ingreso->largo); ?>" required/>
                </div>
              </div>
              <div class="form-group row">
                <label for="exampleInputConfirmPassword2" class="col-sm-3 col-form-label">Ancho *</label>
                <div class="col-sm-9">
                    <input type="number" step="any" name="ancho" id="ancho" class="form-control" value="<?php echo e($ingreso->ancho); ?>" required/>
                </div>
              </div>
             
              <button type="submit" class="btn btn-primary me-2">Guardar cambios</button>
              <button class="btn btn-danger" id="btnClose">Cerrar</button>
            </form>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();

$(document).ready(function () {
    $('#btnClose').click(function () {
        window.opener.location.reload(true);
        window.close();
    });
});

function refreshAndClose() {
    window.opener.location.reload(true);
    window.close();
};

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaCDC\resources\views/entradas/editar.blade.php ENDPATH**/ ?>