<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('icons/mdi/css/materialdesignicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('icons/mdi/css/materialdesignicons.min.css.map')); ?>" rel="stylesheet">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title> 
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\SistemaCDC\resources\views/layouts/login.blade.php ENDPATH**/ ?>