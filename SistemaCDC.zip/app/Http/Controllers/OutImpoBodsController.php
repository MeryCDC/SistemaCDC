<?php

namespace App\Http\Controllers;

use App\Models\out_impo_bods;
use Illuminate\Http\Request;

class OutImpoBodsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\out_impo_bods  $out_impo_bods
     * @return \Illuminate\Http\Response
     */
    public function show(out_impo_bods $out_impo_bods)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\out_impo_bods  $out_impo_bods
     * @return \Illuminate\Http\Response
     */
    public function edit(out_impo_bods $out_impo_bods)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\out_impo_bods  $out_impo_bods
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, out_impo_bods $out_impo_bods)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\out_impo_bods  $out_impo_bods
     * @return \Illuminate\Http\Response
     */
    public function destroy(out_impo_bods $out_impo_bods)
    {
        //
    }
}
